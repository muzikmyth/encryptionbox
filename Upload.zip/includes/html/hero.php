<!-- website hero -->
<div class="hero">
   <div class="container">

      <div class="pull-left">
         <h1><?php echo $website['name'];?></h1>
         <p><?php echo $website['name'];?> is a free online service providing <strong><?php echo $website['count'];?></strong> hashing and<br/> encryption tools for you to use!</p>
      </div>

   </div>
</div>
